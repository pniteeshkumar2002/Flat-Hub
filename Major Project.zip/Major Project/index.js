const express = require('express');
const app = express();
const port = 8080;
const mongoose = require("mongoose");
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');
const methodOverride = require("method-override");
const ejsMate = require("ejs-mate");
// ejs-mate is used to create templete which are used in more than one page of the website
// like Nav-bar and footer are used in all the page of the website 
const ExpressError = require("./utils/ExpressError.js");
const listingsRouter = require('./routes/listing.js');
const reviewsRouter = require('./routes/review.js');
const UserRouter = require('./routes/user.js');
const adminRouter = require('./routes/admin.js');



// const Atlas_Db_url = process.env.ATLASDB_CONNECT_URL;
// const store  = MongoStore.create({
//     mongoUrl: Atlas_Db_url,
//     crypto:{
//         secret:process.env.SECRET
//     },
//     touchAfter: 24*3600
// })
// store.on("error",()=>{
//     console.log("Error in mongo session store",err);
// });
const sessionOption = {
    //  store: store,
    secret:process.env.SECRET,
    resave:false,
    saveUninitialized:true,
    Cookie: {
        expires:Date.now() + 7 * 24 *60 * 60 *1000,
        // cookie will expire after 7 days from current date
        maxAge: 7 * 24 *60 * 60 *1000,
        httpOnly:true //for protect from cross scripting
    }
}

// crypto parameter is basically used to encrypt your secret
// touchAfter: touchAfter is the interval(in second) between session updates
const flash = require('connect-flash');
const passport = require('passport');
const LocalStrategy = require('passport-local');
const User = require("./models/user.js");

app.listen(port,()=>{
    console.log(`Server is listening on port ${port}`);
})
const mongoose_url = 'mongodb://127.0.0.1:27017/wonderlust';

async function main(){
    await mongoose.connect(mongoose_url)
}

main()
.then(res=>{
    console.log("connection established successfully!");
})
.catch(err=>{
    console.log(err);
})

app.engine('ejs', ejsMate); //set engin for ejs-mate
app.set("view engine","ejs");
app.set("views",path.join(__dirname,"views"));
app.use(express.static(path.join(__dirname,"/public")));
app.use(express.urlencoded({extended:true}));
app.use(methodOverride('_method'));
app.use(session(sessionOption));
// app.use(flash()); must be after app.use(session(sessionOption)); otherwise it will not work
app.use(flash());
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// passport.session()
// A web application needs the ability to identify users as they browse from page to page. This series of requests and responses , each associated with the same user, is known as a session 
app.use((req,res,next)=>{
    res.locals.success = req.flash("success");
    res.locals.error=req.flash("error");
    res.locals.currUser = req.user;
    next();
})

app.get("/",(req,res)=>{
  return  res.redirect("/listing");
});
app.use("/listing",listingsRouter);
app.use("/listing/:id/reviews",reviewsRouter);
app.use("/",UserRouter);
app.use("/",adminRouter);

// Default route if any route does not match with the existing route
app.all("*", (req,res,next) =>{
     next(new ExpressError(404,"Page Not Found"));
});
// Below code is the error handler if Any error occur then Next() function execute the below code  
app.use((err,req,res,next)=>{
    let {statuscode=500,message="Something went wrong"} =err;
   return res.status(statuscode).render("error.ejs",{message});
})