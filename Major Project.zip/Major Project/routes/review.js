const express = require('express');
const router = express.Router({mergeParams:true});
const wrapAsync = require("../utils/wrapAsync.js");
const {LoggedIn, reviewOwner,validateReview} = require('../middleware.js');
const reviewController = require('../controllers/reviews.js')

//create Reviews Route 
router.post("/",validateReview,LoggedIn,wrapAsync(reviewController.postReview))
// Delete review route
router.delete("/:reviewId",LoggedIn,reviewOwner,wrapAsync(reviewController.deleteReview))
module.exports = router;