const express = require('express');
const router = express.Router();
const wrapAsync = require("../utils/wrapAsync.js");
const {LoggedIn,isOwner,validateListing} = require("../middleware.js")
const listingController = require('../controllers/listing.js')
const multer  = require('multer')
const {storage} = require('../cloudConfig.js')
const upload = multer({ storage })
const BookingController = require("../controllers/booking.js");
const SearchingController = require("../controllers/searching.js")

router.route("/new")
.get(LoggedIn,listingController.newPage)
.post(LoggedIn,upload.single('listing[image]'),validateListing,wrapAsync(listingController.createNew));

// To Booking the flat
router.get("/mybooking",LoggedIn,wrapAsync(BookingController.myBooing))

// Route to search destination
router.post("/destination",wrapAsync(SearchingController.searched_destination))

router.get("/:filter",wrapAsync(listingController.filter))

router.route("/:id/book")
.get(LoggedIn,wrapAsync(BookingController.bookingPage))
.post(LoggedIn,wrapAsync(BookingController.bookNow));

router.route('/:id/edit')
.get(LoggedIn,wrapAsync(listingController.editPage))
.put(LoggedIn,isOwner,upload.single('listing[image]'),validateListing,wrapAsync(listingController.editListing));

router.get("/",wrapAsync(listingController.index));
router.get("/:id/details",wrapAsync(listingController.details));
router.patch("/:id/cancel_booking",LoggedIn,wrapAsync(BookingController.cancel_booking))
//Delete Listing Route
// When any Listing will be delete then the middleware of findByIdAndDelete also execute whcic are in listing.js directry
router.delete("/:id/delete",LoggedIn,isOwner,wrapAsync(listingController.delteListing));
module.exports = router;