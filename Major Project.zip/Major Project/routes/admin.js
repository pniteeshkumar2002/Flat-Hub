const express = require('express');
const router = express.Router();
const wrapAsync = require("../utils/wrapAsync.js");
// const Admin = require('../models/admin.js')
const {adminLoggedIn} = require('../middleware.js')
const passport = require('passport');
const multer  = require('multer')
const {storage} = require('../adminCloudConfig.js')
const upload = multer({ storage })
const adminController = require('../controllers/admin.js');

router.get("/",wrapAsync(adminController.adminLoginPage));
router.get("/slider",adminLoggedIn,wrapAsync(adminController.adminPanel))
router.route("/signup")
.get(wrapAsync(adminController.adminSignupPage))
.post(wrapAsync(adminController.adminSignup))

router.post("/login",
passport.authenticate("local" ,{failureRedirect: '/admin',failureFlash:true}),wrapAsync(adminController.adminLogin))
router.get("/logout",adminLoggedIn,wrapAsync(adminController.logout))
router.get("/listing",adminLoggedIn,wrapAsync(adminController.Listing))
router.get("/booking",adminLoggedIn,wrapAsync(adminController.booking_Table))
router.get("/bookingCancel",adminLoggedIn,wrapAsync(adminController.booking_Cancel_Table))
router.get("/review",adminLoggedIn,wrapAsync(adminController.TotalReview))
router.get("/reviewDetails",adminLoggedIn,wrapAsync(adminController.reviewDetails))
router.get("/users",adminLoggedIn,wrapAsync(adminController.users))
router.get("/setProfile",adminLoggedIn,wrapAsync(adminController.setProfilePage))
router.post("/setProfilePhoto",adminLoggedIn,upload.single('photo'),wrapAsync(adminController.setProfilePhoto))

router.get("/:id/details",adminLoggedIn,wrapAsync(adminController.visit))
router.get("/:id/booking",adminLoggedIn,wrapAsync(adminController.booking_details))
router.get("/:id/bookingCancel",adminLoggedIn,wrapAsync(adminController.booking_cancel_details))


module.exports = router;