const express = require('express');
const router = express.Router();
const wrapAsync = require('../utils/wrapAsync');
const {saveRedirectUrl} = require('../middleware.js')
const userController = require('../controllers/user.js')
const passport = require('passport');
// Signup Route
router.route("/signup")
.get(userController.signupPage)
.post(wrapAsync(userController.signup))
// Login Route
router.route("/login")
.post(saveRedirectUrl,
passport.authenticate("local" ,{failureRedirect: '/login',failureFlash:true}),wrapAsync(userController.login))
.get(userController.loginPage)

router.route("/forgetpassword")
.get(wrapAsync(userController.forgetpasswordpage))
.post(wrapAsync(userController.checkuserdata))

router.post("/:id/changepassword",wrapAsync(userController.changepassword))

// Logout Route
router.get("/logout",userController.logOut)
module.exports = router;