const Listing = require('./models/listing.js');
const Review = require('./models/review.js');
const {ListingSchema,reviewSchema} = require('./schema.js');
const ExpressError = require("./utils/ExpressError.js");
module.exports.LoggedIn = (req,res,next)=>
{
    if(!req.isAuthenticated())
         { req.session.redirectUrl = req.originalUrl;
            //  console.dir(req);
            req.flash("error","you must be logged in");
           return res.redirect("/login");
        }
        next();
};

module.exports.saveRedirectUrl = (req,res,next)=>{
    if(req.session.redirectUrl)
        {
          return  res.locals.redirectUrl = req.session.redirectUrl;
        }
        next();
}
module.exports.isOwner = async(req,res,next)=>{
    let {id} = req.params;
    let listing = await Listing.findById(id);
    if(!(req.user&&req.user._id.equals(listing.owner._id)))
        {
        req.flash("error","You don't have right");
         return res.redirect(`/listing/${id}/details`);
        }
            next();
}
module.exports.validateListing = (req,res,next)=>{
    let result = ListingSchema.validate(req.body);
    if(result.error)
    {
        throw new ExpressError(400,result.error)
    }else{
        next();
    }
}
module.exports.validateReview = (req,res,next)=>{
    let result = reviewSchema.validate(req.body);
    if(result.error)
    {
        throw new ExpressError(400,result.error)
    }else{
        next();
    }
}
module.exports.reviewOwner = async(req,res,next)=>{
    let {id,reviewId} = req.params;
    let reviews = await Review.findById(reviewId);

    if(!(req.user&&req.user._id.equals(reviews.author._id)))
    {
        req.flash("error","You don't have right to delete this review");
        return res.redirect(`/listing/${id}/details`);
    }
    next();
}

module.exports.adminLoggedIn = (req,res,next)=>
    {
        if(!req.isAuthenticated())
             { req.session.redirectUrl = req.originalUrl;
                //  console.dir(req);
                req.flash("error","you must be logged in");
               return res.redirect("/admin");
            }
            next();
    };