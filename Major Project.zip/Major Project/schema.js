const Joi = require('joi');
// const Listing = require('./models/listing');
module.exports.ListingSchema = Joi.object({
        title:Joi.string().required(),
        description:Joi.string().required(),
        location:Joi.string().required(),
        country:Joi.string().required(),
        price:Joi.number().required().min(100),
        image:Joi.string().allow("",null),
        category:Joi.array()
    }).required();
      
module.exports.reviewSchema = Joi.object({
    review : Joi.object({
    rating:Joi.number().required().max(5).min(1),
    comment :Joi.string().required()
    }).required()
})
module.exports.booking = Joi.object({
     nawme:Joi.string().required(),
     id:Joi.string().required(),
     id_no:Joi.string().required(),
     address:Joi.string().required(),
     city:Joi.string().required(),
     pincode:Joi.number().required(),
     email:Joi.string().required(),
     phone:Joi.number().required(),
     adult:Joi.number().required(),
     kids:Joi.number().required(),
     days:Joi.number().required()
}).required();