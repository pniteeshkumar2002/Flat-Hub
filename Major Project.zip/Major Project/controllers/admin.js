const Admin =require('../models/admin');
const Listing = require('../models/listing');
const User = require('../models/user');
const Booked = require('../models/Book_room');
const Review = require('../models/review');
const Book = require('../models/Book_room');
const user = require('../models/user');

module.exports.adminLoginPage = async(req,res)=>{
    res.render("./Admin/adminLogin.ejs")
}

module.exports.adminPanel = async(req,res)=>{
    res.render('./Admin/adminPanel.ejs')
}
module.exports.adminSignupPage = async(req,res)=>{
    res.render("./Admin/adminSignup.ejs")
}
module.exports.adminSignup = async(req,res) =>{
    try {  let {username,email,password}  =req.body;
    const newUser = new Admin({email,username});
   const registerUser = await Admin.register(newUser,password);
  //  console.log(registerUser);
   req.login(registerUser,(err)=>{
    if(err)
      {
        return next(err);
      }
      req.flash("success","Welcome on Admin Panel!");
    return  res.redirect('/admin');
   })}
  catch (error) {
      req.flash("error",error.message);
     return res.redirect("/signup");
    }
  }

  module.exports.adminLogin = async(req,res)=>{
    req.flash("success","Welcome on Admin Panel")
    res.redirect("/admin/slider");
  }
  module.exports.Listing = async(req,res)=>{
    let listing = await Listing.find().populate('owner');
    res.render('./Admin/adminListing.ejs',{listing});

  }
  module.exports.visit = async(req,res)=>{
    let id = req.params;
    let data = await Listing.findById(id.id).populate("owner");
    res.render("./Admin/adminListingDetails",{data});
  }
  module.exports.users = async(req,res)=>{
    let users = await User.find();
    res.render("./Admin/adminListingUser.ejs",{users})
  }
  module.exports.booking_details = async(req,res)=>{
    let id = req.params;
    let Id = id.id;
    let flat_details =[];
    let booking_details =await Booked.find({$and :[{user:Id},{Booking_Status:"Booked"}]})
    for(let i=0;i<booking_details.length;i++)
      {
       
        if(booking_details[i].Booking_Status=="Booked")
           {

             let booking_id = booking_details[i]._id;
        let data = await Listing.find({booking:{$in: [booking_id,]}}).populate("owner");
        data = data[0]
        flat_details.push(data);}
       
      }
    res.render("./Admin/bookingDetails.ejs",{booking_details,flat_details});

    }
  module.exports.booking_cancel_details = async(req,res)=>{
    let id = req.params;
    let Id = id.id;
    let guest =[];
    let booking_details =await Booked.find({$and :[{user:Id},{Booking_Status:"Cancel"}]})
    for(let i=0;i<booking_details.length;i++)
      {
       
        if(booking_details[i].Booking_Status=="Cancel")
          {
             let booking_id = booking_details[i]._id;
        let data = await Listing.find({booking:booking_id}).populate("owner");
        data = data[0]
        guest.push(data);}
        
      }
    res.render("./Admin/adminBookingCancelDetails.ejs",{booking_details,guest});

  }
  module.exports.booking_Table = async(req,res)=>{
    let booking_details = await Book.find();
    let users =[];
    // let prevId =[];
    // let count =0 
    for(books of booking_details)
      {if(books.Booking_Status==="Booked")
        {
          let booking_u_id = books.user;
        let user = await User.find({_id:booking_u_id});
          users.push(user[0]);
        }
      }
    res.render("./Admin/adminUserBooking.ejs",{users})

  }
  module.exports.booking_Cancel_Table = async(req,res)=>{
    let booking_details = await Book.find();
    let users =[];
    for(books of booking_details)
      {if(books.Booking_Status==="Cancel")
        {
          let booking_u_id = books.user;
        let user = await User.find({_id:booking_u_id});
        users.push(user[0]);
        }
      }
    res.render("./Admin/adminBookingCancel.ejs",{users})

  }
  module.exports.logout = async(req,res)=>{
    req.logOut((err)=>{
      if(err)
        {
         return next(err);
        }
        req.flash("success","You are logged out!");
       return res.redirect("/admin");
    })
  }
  module.exports.TotalReview = async(req,res)=>{
      let review = await Review.find();
      res.render("./Admin/adminReview.ejs",{review});
  }
  module.exports.reviewDetails = async(req,res)=>{
    let reviews = await Review.find().populate("author");
    let lists =[];
    for(let i=0;i<reviews.length;i++)
      {
        let review_id = reviews[i]._id;
        let data = await Listing.find({reviews:review_id})
        lists.push(data[0]);
      }
      res.render("./Admin/adminReviewDetails.ejs",{reviews,lists})
  }
  module.exports.setProfilePage = async(req,res)=>{
    res.render("./Admin/adminProfilePage.ejs");
  }
  module.exports.setProfilePhoto = async(req,res)=>{
  let id = req.user._id;
    let url = req.file.path;
    let filename = req.file.filename;
    let admin = await Admin.find({_id:id});
    admin =admin[0];
    admin.profile.url = url;
    admin.profile.filename = filename;
    admin.save();
    req.flash("success","Profile Updated Successfully");
    res.redirect("/admin/slider");
  }