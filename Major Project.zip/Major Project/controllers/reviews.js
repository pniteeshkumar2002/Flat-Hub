const Review = require('../models/review')
const Listing = require('../models/listing.js');

module.exports.postReview = async(req,res)=>{
    let listing = await Listing.findById(req.params.id);
    let newReview = new Review(req.body.review)
    listing.reviews.push(newReview);
    newReview.author = req.user._id;
    await listing.save();
    await newReview.save();
    req.flash("success","Review Added Successfully!")
    res.redirect(`/listing/${req.params.id}/details`);
   }

module.exports.deleteReview = async(req,res)=>{
    let {id,reviewId} = req.params;
    await Listing.findByIdAndUpdate(id,{$pull :{reviews: reviewId}});
    await Review.findByIdAndDelete(reviewId);
    req.flash("success","Review Deleted Successfully!")
    res.redirect(`/listing/${id}/details`);
}