const User = require('../models/user.js');

module.exports.signupPage = async(req,res)=>{
    res.render("./User/signup.ejs");
}
module.exports.loginPage = (req,res)=>{
   res.render("./User/login.ejs")
}
module.exports.forgetpasswordpage = async(req,res)=>{
 res.render("./User/forget_password.ejs")
}
module.exports.checkuserdata = async(req,res)=>{
  let {username,id,id_no} = req.body;
  let database_data = await User.find({$and:[{username:{$eq:username}},{id:{$eq:id}},{id_no:{$eq:id_no}}]});
  database_data = database_data[0];
  res.render("./User/changepassword.ejs",{database_data})
}
module.exports.changepassword = async(req,res)=>{
  let id = req.params;
  let prevId = id.id;
  let deletedAcount = await User.deleteOne({_id:prevId});
  try {  let {username,email,id,id_no,password}  =req.body;
  const newUser = new User({email,username,id,id_no});
 const registerUser = await User.register(newUser,password);
 req.login(registerUser,(err)=>{
  if(err)
    {
      return next(err);
    }
 })}
catch (error) {
    req.flash("error",error.message);
  res.redirect("/signup");
  return;
  }
  console.log("Deleted Account",deletedAcount)
 res.redirect("/login")
 return;
}
module.exports.signup = async(req,res) =>{
    try {  let {username,email,id,id_no,password}  =req.body;
    const newUser = new User({email,username,id,id_no});
   const registerUser = await User.register(newUser,password);
  //  console.log(registerUser);
   req.login(registerUser,(err)=>{
    if(err)
      {
        return next(err);
      }
      req.flash("success","Welcome on Wonderlust!");
      let redirectUrl = res.locals.redirectUrl || "/login";
      return res.redirect(redirectUrl);
   })}
  catch (error) {
      req.flash("error",error.message);
     return res.redirect("/signup");
    }
  }

  module.exports.login = async(req,res)=>{
    req.flash("success","Welcome back to Flat Hub")
    let redirectUrl = res.locals.redirectUrl || "/listing";
   return res.redirect(redirectUrl);
  }

  module.exports.logOut = (req,res)=>{
    req.logOut((err)=>{
      if(err)
        {
         return next(err);
        }
        req.flash("success","You are logged out!");
        let redirectUrl = res.locals.redirectUrl || "/listing";
       return res.redirect(redirectUrl);
    })
  }