const Listing = require('../models/listing')
// All listing
module.exports.index = async (req,res)=>{
    let lists = await Listing.find({});
    res.render("index.ejs",{lists});
}
// Listing Details
module.exports.details = async (req,res)=>{
    let {id} = req.params;
    // console.log(id);
    let data = await Listing.findById(id).populate({
        path:"reviews",
        populate: {
            path :"author"},
        }).populate("owner");
    if(!data){
        req.flash("error","Listing you requested for does not exist");
      return  res.redirect("/listing");
    }
    // res.send("Request Received Successfully!")
    res.render("details.ejs",{data});
}
// Listing Edit Page
module.exports.editPage = async (req,res)=>{
    let {id} = req.params
    let data = await Listing.findById(id);
    if(!data)
    {
    req.flash("error","Listing you requested for does not exist");
    return res.redirect("/listing");
    }
    res.render("edit.ejs",{data});
}
//Create  New listing Page
module.exports.newPage = (req,res)=>{
    res.render("new.ejs");
}
// Create new Listing
module.exports.createNew = async(req,res)=>{
    let url = req.file.path;
    let filename = req.file.filename;
    const newListing = new Listing(req.body);
    req.flash("success","New Listing Added Successfully")
    newListing.owner = req.user._id;
    newListing.image = {url,filename};
        await newListing.save();
        res.redirect("/listing");
    }
// Listing Edit 
module.exports.editListing = async (req,res)=>{
    let {id} = req.params;
   let listing = await Listing.findByIdAndUpdate(id,req.body,{new:true});
   if(typeof req.file !== 'undefined')
    {let url = req.file.path;
        let filename = req.file.filename;
        listing.image = {url,filename};
    }
    await listing.save();
    req.flash("success","Listing Update Successfully!")
    res.redirect(`/listing/${id}/details`);
}
// Delete Listing
module.exports.delteListing = async (req,res)=>{
    let {id} = req.params;
    await Listing.findByIdAndDelete(id);
    req.flash("success","Listing Deleted Successfully!")
    res.redirect("/listing");
}

module.exports.filter = async(req,res)=>{
    let paramss = req.params;
    // console.log(paramss)
    let lists = await Listing.find({category :{$in :paramss.filter}})
    res.render("index.ejs",{lists});
}
