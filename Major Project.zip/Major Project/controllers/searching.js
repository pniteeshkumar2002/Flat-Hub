const Listing = require('../models/listing')
module.exports.searched_destination = async(req,res)=>{
   let searched_destination = req.body;
   let lists = await Listing.find({country:searched_destination.destination})
   res.render("index.ejs",{lists});
}