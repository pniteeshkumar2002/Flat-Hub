const Book = require("../models/Book_room");
const Listing = require("../models/listing")

module.exports.bookingPage = async(req,res)=>{
    let {id} = req.params;
res.render("book.ejs",{id});
}
module.exports.bookNow = async(req,res)=>{
    
    let newBooking = await new Book(req.body); 
    newBooking.user = req.user._id;
    
    let data = await Listing.findById(req.params.id);
    data.booking.push(newBooking._id);
    req.flash("success","Booked Successfully")
    await newBooking.save();
    await data.save();
    res.redirect("/listing/mybooking");
}
module.exports.myBooing = async(req,res)=>{
    let guest = await Book.find({user: req.user._id})
    let booking_details =[];
    if(guest)
        {
            for(books of guest)
                {
                let booking = await Listing.find({booking: books._id}).populate("owner");
                booking_details.push(booking[0]);
                
            }
        }
    
   res.render("your_booking.ejs",{guest,booking_details});
}
module.exports.cancel_booking = async(req,res)=>{
    let Id =req.params;
    let data = await Book.find({_id:Id.id})
    data[0].Booking_Status = "Cancel";
    data = data[0];
    data.cancelDate = new Date();
    data.save();
    req.flash("success","Booking Cancel Successfully!");
    res.redirect("/listing/mybooking");   
}