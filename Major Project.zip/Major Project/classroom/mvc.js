// MVC  Model,Vuew,Controller
// implement designe pattern for listings