const express = require('express');
const app = express();
const cookieParser = require('cookie-parser')

app.use(cookieParser("secretCode")) // cookies parser middleware
// we will pass a parameter in the cookieParser method as a secret code which can be a string 

app.listen(3000,()=>{
    console.log("Server is listening on port 3000");
})

app.get("/getcookies",(req,res)=>{
    res.cookie("greet","Hello"); //To send the cookie with the response
    res.cookie("madeIn","India");
    res.send("cookee send successfully! ");
})
app.get("/getSignedCookies",(req,res)=>{
    res.cookie("made-in","India",{signed:true});
    res.send("Signed cookee send successfully! ");
})
app.get("/verify",(req,res)=>{
//In case of signed cookie if you tempered the cookie then when you verify the cookie then it will print a null object
// In case if you change the name value of a cookie then it will print the value as false
    console.log(req.signedCookies) //to console signed cookies 
    res.send("Verify");
})
app.get("/",(req,res)=>{
    console.dir(req.cookies) //To show the accepted
    res.send("cookie Accepted");
})

// Stateful Protocal : Stateful Protocal require server to save the status and session information 
// eg: FTP
// Stateless Protocal : Stateless Protocal does not require the server to retain thee server informatiion 
// eg: http

// Express Sessions
// An attempt to make our session stateful
// Express Session store the temporary session related information by using a unique Session id