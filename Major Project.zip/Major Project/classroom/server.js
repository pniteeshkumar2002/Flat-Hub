const express = require('express');
const app = express();
const session = require('express-session');
const flash = require('connect-flash');
const session_option = {secret:"MySecretKey",resave:false,
saveUninitialized: true,};
const path = require('path');


app.set("view engine","ejs");
app.set("views",path.join(__dirname,"views"));
app.use(session(session_option));
app.use(flash());


app.use((req,res,next)=>{
res.locals.successMsg = req.flash("success"); 
res.locals.errorMsg = req.flash("error"); 
next();
})
// when we will use [app.use(session({secret: "MySecretKey"}));] middleware then a session_id create for each route
// if we open the same route in different tab then the session_id will be same for the route which are open in other tab

app.get("/register",(req,res)=>{
    let {name = "Welcome in the world of technology"} = req.query;
    req.session.name = name;
  if(name === 'Welcome in the world of technology')
   {
    req.flash("error","User Not Registered!");
   }else{
    req.flash("success","User registered successfully!");
   }
    res.redirect("/hello");
})
app.get("/test", (req,res)=>{
    res.send("Request Received Successfully! ");
})

app.get("/hello",(req,res)=>{
    // console.log(req.flash("success"));
    res.render("index.ejs",{name:req.session.name});
})

app.get("/reqcount",(req,res)=>{
    if(req.session.count){req.session.count++;}
    else{req.session.count = 1;}
    res.send(`You sent a request ${req.session.count} times`);
})


app.listen(3000,()=>{
    console.log("Server is listening on port 3000");
})


// Connect-Flash
// The flash is a special are of the session used for storing message. Message are written to the flash and cleared after being displayed to the user

// locals var
// locals var does not need to pass in the ejs file when we render the the ejs file
// we can directly use locals var in the ejs file

// Syntax to use locals var
// res.locals.Var_name = Value