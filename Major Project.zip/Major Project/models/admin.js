const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const passportLocalMangoose = require('passport-local-mongoose');


const admin = new Schema({
    email:{
        type: String,
        required:true
    },
    profile:{
        url:{
            type:String,
            default:""
        },
        filename:{
            type:String
        }

    }
})


admin.plugin(passportLocalMangoose);
module.exports = mongoose.model('Admin', admin);