const mongoose = require('mongoose');
const Review = require('./review.js');
const Schema = mongoose.Schema;
const listingSchema = new Schema({
    title : {
        type: String,
        reqiured:true
    },
    description : {
        type:String,
        required:true
    },
    image : {
    //     type:String,
    //     default:"https://a0.muscache.com/im/pictures/miso/Hosting-694576369161952366/original/b32fea9c-af09-4f51-b69a-bd808128a999.jpeg?im_w=1200",
    //     set:(v)=> v ==="" ? "https://a0.muscache.com/im/pictures/miso/Hosting-694576369161952366/original/b32fea9c-af09-4f51-b69a-bd808128a999.jpeg?im_w=1200" : v
    // 
    url : String,
    filename : String
},
    price : {
        type:Number,
        min:100
    },
    location : String,
    country : String,
    reviews :[
        {
            type :Schema.Types.ObjectId,
            ref:"Review"
        }
    ],
    owner : {
        type :Schema.Types.ObjectId,
        ref: "User"
    },
    category :[{type : String}],
    booking :[
        {
            type : Schema.Types.ObjectId,
            ref :"Book"
        }
    ],
    hosting_date:{
        type:Date,
        default :Date.now()
    }
});
// Middleware of findByIdAndDelete 
listingSchema.post("findOneAndDelete",async(listing)=>{
    if(listing)
    {
        await Review.deleteMany({_id: {$in : listing.reviews}});
    }
})

const Listing = mongoose.model("Listing",listingSchema);
module.exports = Listing;


// $pull Operator :
// The $pull operator removes from an existing array all instance of a value or values that match a specified condition