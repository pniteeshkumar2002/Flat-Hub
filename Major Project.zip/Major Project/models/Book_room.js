const { required, number } = require('joi');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const booking = new Schema({
     name:{
        type: String,
        required :true
     },
     id:{
        type: String,
        required: true
     },
     id_no:{
        type: String,
        required:true
     },
     address:{
        type:String,
        required :true
     },
     city:{
        type:String,
        required:true
     },
     pincode:{
        type:Number,
        required:true
     },
     email:{
        type:String,
        required:true
     },
     phone:{
        type:Number,
        required:true
     },
     adult:{
        type:Number,
        required:true
     },
     kids:{
        type:Number,
        required:true
     },
     days:{
        type:Number,
        required:true
     },
     Booking_Status:{
           type:String,
           default: "Booked"
     },
     cancelDate:{
      type: Date,
     },
     booking_date:{
      type:Date,
      default:Date.now()
     },
     user:[
     {
         type:Schema.Types.ObjectId,
         ref:"User"
     }
   ]
});
const Book = mongoose.model("Book",booking);
module.exports = Book;